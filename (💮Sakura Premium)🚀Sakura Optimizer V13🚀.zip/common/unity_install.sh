#!/system/bin/sh
if [ ! -d "$MODPATH" ]; then
  rm -rf /data/data/com.android.vending/cache
fi

