#############################
#FIX BRIGHTNESS🔅 ON CUSTOM ROM#
#############################
# CREDIT BY: ZENIN MADE BY SAKURA#
############################
if getprop ro.vendor.build.fingerprint | grep -iq -e infinix/X6711; then
  setprop ro.vendor.transsion.backlight_hal.optimization 1
fi
