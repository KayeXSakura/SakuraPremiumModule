#!/system/bin/sh
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true
CLEANSERVICE=true
DEBUG=true
MODDIR=/data/adb/modules
unzip -o "$ZIPFILE" 'addon/*' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'sys/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'tmp/*' -d $MODPATH >&2

set_permissions() {
set_perm_recursive $MODPATH/config 0 0 0755 0755
set_perm_recursive $MODPATH/system/* 0 0 0755 0755
set_perm_recursive "$MODPATH/system/bin" 0 0 0755 0755
}
