#!/system/bin/sh
#############################
#DEX OPTIMIZER NI ZENIN AND SAKURA#
#############################
while true
do
    # Function to write a value to a file
    write() {
        local file="$1"
        local value="$2"

        # Bail out if file does not exist
        [[ ! -f "$file" ]] && return 1

        # Make file writable in case it is not already
        chmod +w "$file" 2> /dev/null

        # Write the new value and bail if there's an error
        if ! echo "$value" > "$file" 2> /dev/null; then
            echo "Failed: $file → $value" | tee -a /sdcard/Android/SakuraDexOptilog.log
            return 1
        fi
    }

    # Function to compile apps in Everything-profile
    compile_apps() {
        su -c "cmd package compile -m everything-profile -a" | tee -a /sdcard/Android/SakuraDexOptilog.log
        su -c "pm compile -m everything-profile --secondary-dex -a" | tee -a /sdcard/Android/SakuraDexOptilog.log
    }

    # Function to run Dex2oat optimizer
    run_dex2oat_optimizer() {
        su -c "cmd package bg-dexopt-job" | tee -a /sdcard/Android/SakuraDexOptilog.log
        echo "DexOptimizer Done! By Sakura $(date +"%d-%m-%Y %r" )" >> /storage/emulated/0/DexOptilog.txt
echo "" >> /storage/emulated/0/DexOpti is Done.log
    }

    # Main function to execute all optimizations
    main() {
        compile_apps
        run_dex2oat_optimizer
    }

    # Execute the main function
    main

    # Sleep for 1days hours before running again
    sleep 24h
done


#Magisk Module Ni Sakura
am start -a android.intent.action.VIEW -d https://t.me/MagiskModulesAndApp >/dev/null 2>&1 & >/dev/null 2>&1 &
############################
#REMOVE 60hz When PowerBoost     #
#By Sakura                            #
###########################
while [[ -z $(getprop sys.boot_completed) ]]; do sleep 5; done
sleep 5
service call SurfaceFlinger 1035 i32 0
echo "60hz PowerBoost Lock Removed $(date +"%d-%m-%Y %r" )" >> /storage/emulated/0/PowerBoostRemover.txt
echo "" >> /storage/emulated/0/PowerBoostRemover.log
#############################
LOG_FILE="/data/local/tmp/sakuraxzenlog.txt"
printf "\n" >> $LOG_FILE
date | tee -a $LOG_FILE
############################
# Checking available LTE aggregations#
############################
available_aggregations=$(settings get global aggregated_lte_ca_config)
settings put global aggregated_lte_ca_config "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100"
echo "New LTE aggregation types successfully added."
echo "Current LTE aggregations count: $(echo $available_aggregations | awk -F',' '{print NF}')"
#############################
# Setting GPRS registration parameters#
############################
settings put global gprs_registration_refresh_rate 30 | tee -a $LOG_FILE
settings put global gprs_service_refresh_rate 30 | tee -a $LOG_FILE
####################
# Function to change TTL #
###################
function check_sdk_version() {
  SDK_VERSION=$(getprop ro.build.version.sdk)
  if [[ -z "$SDK_VERSION" ]]; then
    echo "Failed to retrieve SDK version."
    return 1
  fi
  if [[ "$SDK_VERSION" -ge 29 && "$SDK_VERSION" -le 32 ]]; then
    change_ttl_sdk_down
  elif [[ "$SDK_VERSION" -gt 32 ]]; then
    change_ttl_sdk_up
  else
    echo "Unknown SDK version: $SDK_VERSION"
    return 1
  fi
}

function change_ttl_sdk_down() {
  NEW_TTL=$(shuf -i 65-75 -n 1)
  echo $NEW_TTL | tee /proc/sys/net/ipv4/ip_default_ttl > /dev/null
  echo "TTL changed to $NEW_TTL for devices with SDK version 29 to 32."
}

function change_ttl_sdk_up() {
  NEW_TTL=$(shuf -i 65-95 -n 1)
  echo $NEW_TTL | tee /proc/sys/net/ipv4/ip_default_ttl > /dev/null
  echo "TTL changed to $NEW_TTL for devices with SDK version above 32."
}

check_sdk_version
#################
# Increasing HeapSiz #
################
function determine_brand() {
  BRAND=$(getprop ro.product.brand)
  lowercase_brand=$(echo "$BRAND" | tr '[:upper:]' '[:lower:]')
  if [ "$lowercase_brand" == "xiaomi" ]  [ "$lowercase_brand" == "oppo" ]  [ "$lowercase_brand" == "realme" ]  [ "$lowercase_brand" == "poco" ]  [ "$lowercase_brand" == "honor" ]  [ "$lowercase_brand" == "motorola" ]  [ "$lowercase_brand" == "huawei" ]  [ "$lowercase_brand" == "doogee" ]  [ "$lowercase_brand" == "ulefone" ]  [ "$lowercase_brand" == "infinix" ]  [ "$lowercase_brand" == "tcl" ]  [ "$lowercase_brand" == "tecno" ]; then
    decrease_heapsize_crystall
  elif [ "$lowercase_brand" == "samsung" ]  [ "$lowercase_brand" == "redmi" ]  [ "$lowercase_brand" == "sony" ]  [ "$lowercase_brand" == "zte" ]  [ "$lowercase_brand" == "asus" ]  [ "$lowercase_brand" == "google" ] || [ "$lowercase_brand" == "oneplus" ]; then
    decrease_heapsize_crystalls
  else
    echo "Unknown device brand: $BRAND"
  fi
}
function decrease_heapsize_crystall() {
  TOTAL_RAM=$(grep "MemTotal" /proc/meminfo | awk '{print $2}')
  if [ $TOTAL_RAM -lt 2097152 ]; then
    HEAP_SIZE="64m"
  elif [ $TOTAL_RAM -lt 4194304 ]; then
    HEAP_SIZE="128m"
  elif [ $TOTAL_RAM -lt 6291456 ]; then
    HEAP_SIZE="256m"
  elif [ $TOTAL_RAM -lt 8388608 ]; then
    HEAP_SIZE="512m"
  elif [ $TOTAL_RAM -lt 10485760 ]; then
    HEAP_SIZE="512m"
  elif [ $TOTAL_RAM -lt 12582912 ]; then
    HEAP_SIZE="512m"
  elif [ $TOTAL_RAM -lt 14680064 ]; then
    HEAP_SIZE="1024m"
  elif [ $TOTAL_RAM -lt 16777216 ]; then
    HEAP_SIZE="1024m"
  else
    HEAP_SIZE="1024m"
  fi
  echo "Set dalvik.vm.heapsize to $HEAP_SIZE"
  echo "dalvik.vm.heapsize=$HEAP_SIZE" >> $LOG_FILE
  setprop dalvik.vm.heapsize "$HEAP_SIZE" 
}
function decrease_heapsize_crystalls() {
  TOTAL_RAM=$(grep "MemTotal" /proc/meminfo | awk '{print $2}')
  if [ $TOTAL_RAM -lt 2097152 ]; then
    HEAP_SIZE="128m"
  elif [ $TOTAL_RAM -lt 4194304 ]; then
    HEAP_SIZE="256m"
  elif [ $TOTAL_RAM -lt 6291456 ]; then
    HEAP_SIZE="512m"
  elif [ $TOTAL_RAM -lt 8388608 ]; then
    HEAP_SIZE="512m"
  elif [ $TOTAL_RAM -lt 10485760 ]; then
    HEAP_SIZE="512m"
  elif [ $TOTAL_RAM -lt 12582912 ]; then
    HEAP_SIZE="512m"
  elif [ $TOTAL_RAM -lt 14680064 ]; then
    HEAP_SIZE="1024m"
  elif [ $TOTAL_RAM -lt 16777216 ]; then
    HEAP_SIZE="1024m"
  else
    HEAP_SIZE="1024m"
  fi
  echo "Set dalvik.vm.heapsize to $HEAP_SIZE"
  echo "dalvik.vm.heapsize=$HEAP_SIZE" >> $LOG_FILE
  setprop dalvik.vm.heapsize "$HEAP_SIZE" 
}
determine_brand
###############
# Optimizing TCP/IP#
###############
sysctl -w net.ipv4.tcp_tw_reuse=1
sysctl -w net.ipv4.tcp_window_scaling=1
sysctl -w net.ipv4.tcp_sack=1
sysctl -w net.ipv4.tcp_timestamps=1
sysctl -w net.ipv4.tcp_fin_timeout=15
sysctl -w net.ipv4.tcp_mtu_probing=2
sysctl -w net.ipv4.tcp_max_syn_backlog=8192
sysctl -w net.core.rmem_default=50331648
sysctl -w net.core.rmem_max=67108864
sysctl -w net.core.wmem_default=50331648
sysctl -w net.core.wmem_max=67108864
sysctl -w net.core.netdev_max_backlog=300
sysctl -w fs.file-max=65535
sysctl -w net.ipv4.tcp_fastopen=3
sysctl -w net.core.somaxconn=16384
sysctl -w net.ipv4.tcp_slow_start_after_idle=0
sysctl -w net.ipv4.tcp_rmem="8192 174760 349520"
sysctl -w net.ipv4.tcp_wmem="8192 131072 262144"
sysctl -w kernel.panic_on_oops=1

date | tee -a $LOG_FILE
##############
# Improve Touch  #
##############
echo "0" > "/sys/module/msm_perfmon/parameters/touch_boost_enable"
echo "0" > "/sys/module/msm_perfmon/parameters/touch_boost_freq"
echo "0" > "/sys/module/msm_performance/parameters/touchboost"
echo "0" > "/sys/power/pnpmgr/touch_boost"
write /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor performance
write /sys/devices/system/cpu/cpufreq/performance/above_hispeed_delay 0
write /sys/devices/system/cpu/cpufreq/performance/boost 1
write /sys/devices/system/cpu/cpufreq/performance/go_hispeed_load 75
write /sys/devices/system/cpu/cpufreq/performance/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpufreq/performance/align_windows 1
write /sys/module/adreno_idler/parameters/adreno_idler_active 0
write /sys/module/lazyplug/parameters/nr_possible_cores 8
write /sys/module/msm_performance/parameters/touchboost 1
write /dev/cpuset/foreground/boost/cpus 4-7
write /dev/cpuset/foreground/cpus 0-3,4-7
write /dev/cpuset/top-app/cpus 0-7

while [ `getprop vendor.post_boot.parsed` != "1" ]; do
    sleep 1s
done

sleep 10s
###########################
# Virtual Memory Tweaks Set Config #
###########################
stop perfd
echo '5' > /proc/sys/vm/swappiness;
echo '0' > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk;
echo '80' > /proc/sys/vm/vfs_cache_pressure;
echo '0' > /proc/sys/vm/extra_free_kbytes;
echo '128' > /sys/block/mmcblk0/queue/read_ahead_kb;
echo '128' > /sys/block/mmcblk1/queue/read_ahead_kb;
echo '1024' > /sys/block/ram0/queue/read_ahead_kb
echo '1024' > /sys/block/ram1/queue/read_ahead_kb
echo '1024' > /sys/block/ram2/queue/read_ahead_kb
echo '1024' > /sys/block/ram3/queue/read_ahead_kb
echo '1024' > /sys/block/ram4/queue/read_ahead_kb
echo '1024' > /sys/block/ram5/queue/read_ahead_kb
echo '1024' > /sys/block/ram6/queue/read_ahead_kb
echo '1024' > /sys/block/ram7/queue/read_ahead_kb
echo '1024' > /sys/block/ram8/queue/read_ahead_kb
echo '1024' > /sys/block/ram9/queue/read_ahead_kb
echo '1024' > /sys/block/ram10/queue/read_ahead_kb
echo '1024' > /sys/block/ram11/queue/read_ahead_kb
echo '1024' > /sys/block/ram12/queue/read_ahead_kb
echo '1024' > /sys/block/ram13/queue/read_ahead_kb
echo '1024' > /sys/block/ram14/queue/read_ahead_kb
echo '1024' > /sys/block/ram15/queue/read_ahead_kb
echo '1024' > /sys/block/vnswap0/queue/read_ahead_kb
echo '4096' > /proc/sys/vm/min_free_kbytes;
echo '0' > /proc/sys/vm/oom_kill_allocating_task;
echo '5' > /proc/sys/vm/dirty_ratio;
echo '20' > /proc/sys/vm/dirty_background_ratio;
sleep 05
chmod 666 /sys/module/lowmemorykiller/parameters/minfree;
chown root /sys/module/lowmemorykiller/parameters/minfree;
echo '21816,29088,36360,43632,50904,65448' > /sys/module/lowmemorykiller/parameters/minfree;
rm /data/system/perfd/default_values;
start perfd

setenforce 0
stop logd
stop thermald
echo always_on > /sys/devices/platform/13040000.mali/power_policy;
echo alweys_on > /sys/devices/platform/13040000.mali/gpuinfo;
echo alweys_support >/sys/devices/system/cpu/cpufreq/policy4/scaling_setspeed;
echo alweys_support >/sys/devices/system/cpu/cpufreq/policy6/scaling_setspeed;
echo '1' > /sys/devices/system/cpu/sched/cpu_prefer;
echo boost > /sys/devices/system/cpu/sched/sched_boost;
echo '1' > /sys/devices/system/cpu/eas/enable;
###################
# performance enable  #
##################
echo '1' > /sys/devices/system/cpu/perf/enable;
chmod '0644' > /sys/devices/system/cpu/perf/enable;
echo 'boost' > /sys/devices/system/cpu/sched/sched_boost;
echo '3' > /proc/cpufreq/cpufreq_power_mode;
echo '1' > /proc/cpufreq/cpufreq_imax_enable;
echo '0' > /proc/cpufreq/cpufreq_imax_thermal_protect;
sleep 0.2
echo '35' > /dev/stune/foreground/schedtune.boost;
chmod '0444' /dev/stune/foreground/schedtune.boost;
echo '1' > /proc/cpufreq/cpufreq_cci_mode;
chmod '0444' /proc/cpufreq/cpufreq_cci_mode;
#########################
# Force GPU for touch render. #
########################
echo '7035' > /sys/class/touch/switch/set_touchscreen;
echo '8002' > /sys/class/touch/switch/set_touchscreen;
echo '11000' > /sys/class/touch/switch/set_touchscreen;
echo '13060' > /sys/class/touch/switch/set_touchscreen;
echo '14005' > /sys/class/touch/switch/set_touchscreen;
########
# Boost  #
########
echo '1'  > /sys/module/msm_performance/parameters/touchboost
echo '1' > /sys/power/pnpmgr/touch_boost
#############################
# Google Service Enable Necessary     #
# Running On Background By Sakura   #
#############################
su -c 'pm disable com.google.android.gms/.update.SystemUpdateActivity'
su -c 'pm disable com.google.android.gms/.update.SystemUpdateService'
su -c 'pm disable com.google.android.gms/.update.SystemUpdateServiceActiveReceiver'
su -c 'pm disable com.google.android.gms/.update.SystemUpdateServiceReceiver'
su -c 'pm disable com.google.android.gms/.update.SystemUpdateServiceSecretCodeReceiver'
su -c 'pm disable com.google.android.gsf/.update.SystemUpdateActivity'
su -c 'pm disable com.google.android.gsf/.update.SystemUpdatePanoActivity'
su -c 'pm disable com.google.android.gsf/.update.SystemUpdateService'
su -c 'pm disable com.google.android.gsf/.update.SystemUpdateServiceReceiver'
su -c 'pm disable com.google.android.gsf/.update.SystemUpdateServiceSecretCodeReceiver'
#######################
# Enable GED boost settings  #
######################
# GPU BOOST BY SAKURA   #
######################
echo '1' > /sys/module/ged/parameters/gx_frc_mode
echo '1' > /sys/module/ged/parameters/gx_game_mode
echo '1' > /sys/module/ged/parameters/gx_force_cpu_boost
echo '1' > /sys/module/ged/parameters/boost_amp
echo '1' > /sys/module/ged/parameters/gx_3D_benchmark_on
echo '1' > /sys/module/ged/parameters/boost_extra
echo '1' > /sys/module/ged/parameters/enable_gpu_boost
echo '1' > /sys/module/ged/parameters/ged_boost_enable
echo '1' > /sys/module/ged/parameters/enable_game_self_frc_detect
echo '10' > /sys/module/ged/parameters/gpu_idle
echo '80' > /sys/module/ged/parameters/cpu_boost_policy
echo '1' > /sys/module/ged/parameters/ged_force_mdp_enable
echo '1' > /sys/module/ged/parameters/enable_cpu_boost
echo '1' > /sys/module/ged/parameters/gx_boost_on
echo '1' > /sys/module/ged/parameters/ged_smart_boost
chmod 0755 /sys/module/ged/parameters/boost_gpu_enable
echo '1' > /sys/module/ged/parameters/boost_gpu_enable
chmod 0755 /sys/module/ged/parameters/gpu_dvfs_enable
chmod 0755 /sys/module/ged/parameters/g_fb_dvfs_threshold
echo '1' > /sys/module/ged/parameters/g_fb_dvfs_threshold
echo '1' > /sys/module/ged/parameters/gpu_dvfs_enable# Enable GED boost settings
echo '1' > /sys/module/ged/parameters/gx_frc_mode
echo '1' > /sys/module/ged/parameters/gx_game_mode
echo '1' > /sys/module/ged/parameters/gx_force_cpu_boost
echo '1' > /sys/module/ged/parameters/boost_amp
echo '1' > /sys/module/ged/parameters/gx_3D_benchmark_on
echo '1' > /sys/module/ged/parameters/boost_extra
echo '1' > /sys/module/ged/parameters/enable_gpu_boost
echo '1' > /sys/module/ged/parameters/ged_boost_enable
echo '1' > /sys/module/ged/parameters/enable_game_self_frc_detect
echo '10' > /sys/module/ged/parameters/gpu_idle
echo '80' > /sys/module/ged/parameters/cpu_boost_policy
echo '1' > /sys/module/ged/parameters/ged_force_mdp_enable
echo '1' > /sys/module/ged/parameters/enable_cpu_boost
echo '1' > /sys/module/ged/parameters/gx_boost_on
echo '1' > /sys/module/ged/parameters/ged_smart_boost
chmod 0755 /sys/module/ged/parameters/boost_gpu_enable
echo '1' > /sys/module/ged/parameters/boost_gpu_enable
chmod 0755 /sys/module/ged/parameters/gpu_dvfs_enable
chmod 0755 /sys/module/ged/parameters/g_fb_dvfs_threshold
echo '1' > /sys/module/ged/parameters/g_fb_dvfs_threshold
echo '1' > /sys/module/ged/parameters/gpu_dvfs_enable
############################
#Deep Doze Enhancement Zen/Sakura #
############################
rm -f /storage/emulated/0/*.log;
settings delete global device_idle_constants
settings delete global device_idle_constants_user
dumpsys deviceidle enable light
dumpsys deviceidle enable deep
sleep 5
settings put global device_idle_constants
echo "Doze Done! By Sakura $(date +"%d-%m-%Y %r" )" >> /storage/emulated/0/sakura_doze.log
echo "" >> /storage/emulated/0/sakura_doze.log
###########################
# Add ZRAM FOR ZRAM 0 BY Zenin. #
###########################
swapoff /dev/block/zram0
echo "1" > /sys/block/zram0/reset
echo "4294967296" > /sys/block/zram0/disksize
echo "4096M" > /sys/block/zram0/mem_limit
echo "8" > /sys/block/zram0/max_comp_streams
mkswap /dev/block/zram0
swapon /dev/block/zram0
###################
# Tweaking (Tweaks)     #
###################
su -c "cmd settings put global activity_starts_logging_enabled 0"
su -c "cmd settings put global wifi_scan_always_enabled 0"
su -c "cmd settings put system send_security_reports 0"
##################
#   GPS  Services      #
#################
su -c "pm disable com.google.android.gms/.chimera.GmsIntentOperationService"
su -c "pm disable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver"
##################
# Made By Sakura      #
##################
echo "0 0 0 0" > "/proc/sys/kernel/printk"
echo "0" > "/sys/kernel/printk_mode/printk_mode"
echo "0" > "/sys/module/printk/parameters/cpu"
echo "0" > "/sys/module/printk/parameters/pid"
echo "0" > "/sys/module/printk/parameters/printk_ratelimit"
echo "0" > "/sys/module/printk/parameters/time"
echo "1" > "/sys/module/printk/parameters/console_suspend"
echo "1" > "/sys/module/printk/parameters/ignore_loglevel"
echo "off" > "/proc/sys/kernel/printk_devkmsg"
##############
# Ramdumps    #
##############
for parameters in /sys/module/subsystem_restart/parameters; do
    echo "0" > "$parameters/enable_mini_ramdumps"
    echo "0" > "$parameters/enable_ramdumps"
##############
# VM Tweaks   #
#############
echo "50" > /proc/sys/vm/vfs_cache_pressure
echo "30" > /proc/sys/vm/stat_interval
echo "0" > /proc/sys/vm/compaction_proactiveness
echo "60" > /proc/sys/vm/dirty_ratio
echo "30" > /proc/sys/vm/dirty_background_ratio
echo "0" > /proc/sys/vm/page-cluster
for virtual_memory in /proc/sys/vm; do
    echo "3" > "$virtual_memory/drop_caches"
###################
# Disable Kernel Panic #
##################
echo "0" > /proc/sys/kernel/panic
echo "0" > /proc/sys/kernel/panic_on_oops
echo "0" > /proc/sys/kernel/panic_on_rcu_stall
echo "0" > /proc/sys/kernel/panic_on_warn
echo "0" > /sys/module/kernel/parameters/panic
echo "0" > /sys/module/kernel/parameters/panic_on_warn
echo "0" > /sys/module/kernel/parameters/panic_on_oops
echo "0" > /sys/vm/panic_on_oom
###########
# FSTRIM   #
##########
fstrim -v /system
fstrim -v /vendor
fstrim -v /data
fstrim -v /cache
fstrim -v /system
fstrim -v /vendor
fstrim -v /metadata
fstrim -v /odm
fstrim -v /system_ext
fstrim -v  /product
fstrim -v /data
fstrim -v /cache
####################
# CACHE CLEANER      #
###################
LOG_FILE=" /storage/emulated/0/SakuraCacheCleaner.log"  # Set the path to your log file

while true; do
    echo "Cleanup started at $(date)" >> $LOG_FILE

    # Cleanup commands
    rm -rf /data/media/0/mtklog >> $LOG_FILE 2>&1
    rm -rf /data/media/0/ramdump >> $LOG_FILE 2>&1
    rm -rf /data/misc/*stats/* >> $LOG_FILE 2>&1
    rm -rf /data/misc/bootstat/* >> $LOG_FILE 2>&1
    rm -rf /data/misc/boottrace/* >> $LOG_FILE 2>&1
    rm -rf /data/misc/dropbox/* >> $LOG_FILE 2>&1
    rm -rf /data/misc/stats*/* >> $LOG_FILE 2>&1
    rm -rf /data/misc/tombstones/* >> $LOG_FILE 2>&1
    rm -rf /data/misc/trace/* >> $LOG_FILE 2>&1
    rm -rf /data/mlog/* >> $LOG_FILE 2>&1
    rm -rf /data/system/*stats/* >> $LOG_FILE 2>&1
    rm -rf /data/system/bootstat/* >> $LOG_FILE 2>&1
    rm -rf /data/system/boottrace/* >> $LOG_FILE 2>&1
    rm -rf /data/system/dropbox/* >> $LOG_FILE 2>&1
    rm -rf /data/system/shared_prefs/* >> $LOG_FILE 2>&1
    rm -rf /data/system/stats*/* >> $LOG_FILE 2>&1
    rm -rf /data/system/tombstones/* >> $LOG_FILE 2>&1
    rm -rf /data/system/trace/* >> $LOG_FILE 2>&1
    rm -rf /data/system/usagestats/* >> $LOG_FILE 2>&1
    rm -rf /data/system_ce/0/recent_*/* >> $LOG_FILE 2>&1
    rm -rf /data/system_ce/0/recent_tasks/* >> $LOG_FILE 2>&1
    rm -rf /data/tombstones/* >> $LOG_FILE 2>&1
    rm -rf /data/vendor/*stats/* >> $LOG_FILE 2>&1
    rm -rf /data/vendor/bootstat/* >> $LOG_FILE 2>&1
    rm -rf /data/vendor/boottrace/* >> $LOG_FILE 2>&1
    rm -rf /data/vendor/charge_logger/* >> $LOG_FILE 2>&1
    rm -rf /data/vendor/dropbox/* >> $LOG_FILE 2>&1
    rm -rf /data/vendor/stats*/* >> $LOG_FILE 2>&1
    rm -rf /data/vendor/tombstones/* >> $LOG_FILE 2>&1
    rm -rf /data/vendor/trace/* >> $LOG_FILE 2>&1
    rm -rf /data/vendor/wlan_logs >> $LOG_FILE 2>&1
    
    find /data \( -path "/data/*_log/*" -o \
                    -path "/data/*_logs/*" -o \
                    -path "/data/*_logger/*" -o \
                    -path "/data/traces/*" -o \
                    -path "/data/logger*/*" \) -exec rm -rf {} + >> $LOG_FILE 2>&1
    
    find /data/data/*/cache/* -delete &>/dev/null
    find /data/data/*/code_cache/* -delete &>/dev/null
    find /data/user_de/*/*/cache/* -delete &>/dev/null
    find /data/user_de/*/*/code_cache/* -delete &>/dev/null
    find /sdcard/Android/data/*/cache/* -delete &>/dev/null
    find /storage/emulated/0/ \( -type f -o -type d \) -name '*cache*' -exec rm -rf {} + >> $LOG_FILE 2>&1
    rm -rf /data/resource-cache/* >> $LOG_FILE 2>&1
    rm -rf /cache/* >> $LOG_FILE 2>&1
    rm -rf /data/system/package_cache/* >> $LOG_FILE 2>&1
    rm -rf /data/system/cache/* >> $LOG_FILE 2>&1
    rm -rf /data/vendor/cache/* >> $LOG_FILE 2>&1
    rm -rf /data/misc/cache/* >> $LOG_FILE 2>&1
    rm -rf /data/dalvik-cache >> $LOG_FILE 2>&1
    find /data/app/ -type f -name "*.art" -exec rm {} + >> $LOG_FILE 2>&1
    find /data -type f -name "*.bak" -exec rm -vf {} + >> $LOG_FILE 2>&1
    find /data/ -type f -name "*.log" -exec rm -vf {} + >> $LOG_FILE 2>&1
    find /storage/emulated/0/ -name "*.thumbnails" -exec rm -vf {} + >> $LOG_FILE 2>&1
    find /storage/emulated/0/ -type f -name "*.nomedia" -exec rm -vf {} + >> $LOG_FILE 2>&1
    find /data/data -type f -name "gms" -exec rm -vf {} + >> $LOG_FILE 2>&1
    find /storage/emulated/0 -type d -empty -print -exec rmdir {} + >> $LOG_FILE 2>&1
    
    echo "Cleanup finished at $(date)" >> $LOG_FILE
    echo "Cleaning Cache is Done! By Sakura $(date +"%d-%m-%Y %r" )" >> /storage/emulated/0/SakuraCacheCleanerDone.log
    echo "" >> /storage/emulated/0/SakuraCacheCleanerDone.log

    sleep 18000  # Sleep for 5 hours (18000 seconds)
done
#############
# LMK.         #
############
echo "2560,5120,11520,25600,35840,38400" > /sys/module/lowmemorykiller/parameters/minfree
###############
#Permission To Run#
###############
chmod +x /data/adb/modules/KayeXSakura6in1/service.sh
#########################
MODDIR=${0%/*}
sleep 5
for i in $MODDIR/config/*; do
  case $i in
    *-ls|*-ls.sh) ;;
    *) if [ -f "$i" -a -x "$i" ]; then $i & fi;;
  esac
done
############
# Notification  #
###########
tn