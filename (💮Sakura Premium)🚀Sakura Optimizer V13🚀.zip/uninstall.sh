#!/system/bin/sh
############
# Net settings #
############
{
net.tcp.buffersize.default=4096,87380,256960,4096,16384,256960
net.tcp.buffersize.wifi=4096,87380,256960,4096,16384,256960
net.tcp.buffersize.umts=4096,87380,256960,4096,16384,256960
net.tcp.buffersize.gprs=4096,87380,256960,4096,16384,256960
net.tcp.buffersize.edge=4096,87380,256960,4096,16384,256960
net.tcp.buffersize.hsdpa=4096,87380,256960,4096,16384,256960
net.tcp.buffersize.hspa=4096,87380,256960,4096,16384,256960
net.tcp.buffersize.hspap=4096,87380,256960,4096,16384,256960
net.tcp.buffersize.lte=4096,87380,256960,4096,16384,256960
net.ipv4.tcp_congestion_control=cubic
net.ipv6.tcp_window_scaling=1
net.ipv6.tcp_sack=1
net.ipv6.tcp_timestamps=1
net.ipv6.tcp_fin_timeout=60
net.ipv6.tcp_congestion_control=cubic
net.ipv6.tcp_mtu_probing=0
net.ipv6.tcp_max_syn_backlog=1280
net.ipv6.tcp_congestion_control=reno
net.ipv6.tcp_slow_start_after_idle=1
net.ipv6.tcp_rmem=4096 87380 256960
net.ipv6.tcp_wmem=4096 16384 256960
net.ipv6.tcp_fastopen=0
net.wlan0.scan_freq=0

###########
# Ro settings #
###########
ro.telephony.default_network=10
ro.config.combined_signal=true
ro.ril.def.agps.mode=2
ro.ril.gprsclass=10
ro.ril.hsdpa.category=24
ro.ril.hsupa.category=6
ro.ril.hsxpa=5
ro.ril.enable.dtm=1
ro.ril.enable.amr.wideband=1

##############
# Persist settings #
##############
persist.radio.lte_band=1,2,3,4,5,7,8,20,28
persist.radio.lte_cmds_enabled=0
persist.sys.strict_lte=1
# LTE-Advanced
persist.telephony.lteA=false
persist.telephony.lteA.LAA=false
persist.telephony.lteA.MIMO=1x1
persist.telephony.lteA.RxDivSetting=0
persist.telephony.lteA.CarrierAggregation=0
# AAT & EONS
persist.cust.tel.eons=0
persist.radio.aktive_aat=0

##############
# Debug settings #
##############
debug.hwui.render_dirty_regions=true

############
# Sys settings #
############
sys.net.tcp.buffersize.default=4096,87380,256960,4096,16384,256960
sys.net.tcp.buffersize.wifi=4096,87380,256960,4096,16384,256960
sys.telephony.ril.max_c1_4G=16
sys.telephony.ril.max_c1_5G=16

###########
# Ril settings #
###########
ril.disable.eap1=0
# Remove the wifi.cfg file
rm -f /data/vendor/wifi/wifi.cfg

# Restore the original file (if it exists)
if [ -f /data/vendor/wifi/wifi.cfg.bak ]; then
  mv /data/vendor/wifi/wifi.cfg.bak /data/vendor/wifi/wifi.cfg
fi

resetprop persist.spectrum.kernel 0
resetprop spectrum.support 0

# Restart the Wi-Fi service
stop vendor.wificond
start vendor.wificond

ui_print "Wi-Fi configuration file has been restored."


su -c 'pm enable com.google.android.gms'
su -c 'pm enable com.google.android.gsf'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateActivity'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateService'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceActiveReceiver'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceReceiver'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceSecretCodeReceiver'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateActivity'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateService'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceReceiver'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceSecretCodeReceiver'

# Don't modify anything after this
if [ -f $INFO ]; then
  while read LINE; do
    if [ "$(echo -n $LINE | tail -c 1)" == "~" ]; then
      continue
    elif [ -f "$LINE~" ]; then
      mv -f $LINE~ $LINE
    else
      rm -f $LINE
      while true; do
        LINE=$(dirname $LINE)
        [ "$(ls -A $LINE 2>/dev/null)" ] && break 1 || rm -rf $LINE
      done
    fi
  done < $INFO
  rm -f $INFO
fi
[[ -f "$INFO" ]] && 
  while read LINE; do
    if [[ "$(echo -n "$LINE" | tail -c 1)" == "~" ]]; then
      continue
    elif [[ -f "$LINE~" ]]; then
      mv -f "$LINE~" "$LINE"
    else
      rm -f "$LINE"
      while true; do
        LINE=$(dirname $LINE)
        [[ "$(ls -A $LINE 2>/dev/null)" ]] && break 1 || rm -rf "$LINE"
      done
    fi
  done < $INFO
  rm -f "$INFO"
}